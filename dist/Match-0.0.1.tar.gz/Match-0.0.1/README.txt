I created this module in order to help check large chains or sequences which seemed painful to me to do each time like the hashes of sequences when using the cryptography module in python
